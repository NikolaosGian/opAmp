%const values
L = 1E-6   % ?m
Cox = 4.6E-15       % fF/?M^2
kn = 175E-6      % ??/V^2
kp = 60E-6         % ??/V^2
VTN = 0.5       % V
VTP = -0.6      % V
Cl = 2.29E-12
VDD = 1.887
VSS = -1.887
Cc = 1E-12         % pF
SR = 20E6       % V/?S
S3 = 1
S4 = S3
W3 = L * S3       % ?m
GB = 10E6         % MHz 
lamda_p = 0.15
lamda_n = 0.05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I5 = SR * Cc     % current I5
Iref = I5

Cgs3 = 0.667 * L*W3 * Cox
%Cgs4 = Cgs3
  
Id3 = I5/2
Vov = sqrt((2*Id3)/(kn*S3))
gm3 = (2*Id3)/Vov
gm4 = gm3
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input Stage
gm1 = GB* Cc * 2 * 3.14
gm2 = gm1
S1 = gm1/(kp*I5) * 10^(-4)
S2 = S1
   
Vin_min = -0.1
Vin_max = 0.1
Vds5_sat = Vin_min - VSS - sqrt(I5/(kp*S1)) - VTP
   
if ( Vds5_sat > 0.1 )
    S5 =(2*I5)/(kp * Vds5_sat^2)
    if S5 < 1 
        S5 = 1
    end   
    S8 = S5
else
    fprint("Problem on VDS5_SAT!")
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output stage
gm6 = 2.2 * gm2 *(Cl/Cc) 
S6 = 2*S4
I6 = gm6^2 /(2*kn*S6)
S7 = S5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The final W
W1 = S1*L
W2 = S2*L
W3 = S3*L 
W4 = S4*L 
W5 = S5*L 
W6 = S6*L  
W7 = S7 * L  
W8 = S8 *L 
A = (2 * gm2 * gm6) / ((I5 * (lamda_n +lamda_p) * I6 * (lamda_n + lamda_p)))  
Pdiss = (I5 + I6) * (VDD + abs(VSS)) 